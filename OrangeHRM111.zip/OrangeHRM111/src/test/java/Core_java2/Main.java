package Core_java2;

import core_java.Absclass;

public class Main extends Absclass {

	public static void main(String[] args) {
		

	}

	@Override
	public void Login() {
		
		
	}
	
	

}
