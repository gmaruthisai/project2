package Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class All_actions {
	
	static WebDriver driver;
  @Test
  public void Action_tests()  throws Exception
  {
	  driver = TestBrowser.OpenChromeBrowser();
	  
	  driver.get("https://opensource-demo.orangehrmlive.com/");
	  findElement(By.id("txtUsername")).sendKeys("Admin");
	  findElement(By.id("txtPassword")).sendKeys("admin123");
	  findElement(By.id("btnLogin")).click();			
	  
	 // WebElement Login_button = findElement(By.id("btnLogin"));
	  WebElement Admin = findElement(By.id("menu_admin_viewAdminModule"));
	  WebElement Users_management = findElement(By.id("menu_admin_UserManagement"));
	  WebElement Users = findElement(By.id("menu_admin_viewSystemUsers"));
	  
	  Actions actions1 = new Actions(driver);
	  
	 // actions1.moveToElement(Login_button).click().build().perform();
	  actions1.moveToElement(Admin).
	  moveToElement(Users_management).
	  moveToElement(Users).click().build().perform();
	  
  }
  
  @Test
  public void Action_Doubleclick()  throws Exception
  {
	  driver = TestBrowser.OpenChromeBrowser();
	  
	  driver.get("http://testautomationpractice.blogspot.com/");
	  
	  WebElement copy =findElement(By.xpath("//*[@id=\"HTML10\"]/div[1]/button"));
	  
	  WebElement source = findElement(By.id("draggable"));
	  WebElement Target = findElement(By.id("droppable"));
	  
	  Actions action2 =new Actions(driver);
	  
	  action2.doubleClick(copy).perform();
	  action2.dragAndDrop(source,Target).perform();
	  
  }
  
  @Test
  public void Action_Rightclick()  throws Exception
  {
	  driver = TestBrowser.OpenChromeBrowser();
	  
	  driver.get("https://swisnl.github.io/jQuery-contextMenu/demo.html");
	  WebElement Rclick =findElement(By.xpath("/html/body/div/section/div/div/div/p/span"));
	  
	  Actions actions3 = new Actions(driver);
	  
	  actions3.contextClick(Rclick).perform();

	  
  }
  
  
  
  

public  WebElement findElement(By by) throws Exception 
	{

		WebElement elem = driver.findElement(by);  
		
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		return elem;
	}
}
