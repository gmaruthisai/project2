package Failed_testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class Fail {
	
	WebDriver driver;
  @Test
  public void fail1() throws Exception
  {
	  driver = TestBrowser.OpenChromeBrowser();
		
		//OpenUrl
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
		driver.findElement(By.name("txtUsername")).sendKeys("Admin");
		driver.findElement(By.name("txtPassword")).sendKeys("Admin123");
		
		driver.quit();
	  
  }
  @Test
	public void Mercury() throws Exception {
		
		WebDriver driver;
		
		//OpenChromeVrowser
		driver = TestBrowser.FirefoxBrowser();
		
		//OpenUrl
		driver.get("http://google.co.in");
		Thread.sleep(10000);
		//SendKeys
		
		
		//Close Browser		
		driver.quit();
	}
  @Test 
  public void facebook() throws Exception
  {
	  driver = TestBrowser.OpenChromeBrowser();
		
		//OpenUrl
		driver.get("https://www.facebook.com/");
	  
  }
}
