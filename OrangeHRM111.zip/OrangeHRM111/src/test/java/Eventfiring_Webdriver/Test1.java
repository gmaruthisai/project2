package Eventfiring_Webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.Test;

import CommonUtil.EventHandler;

public class Test1 {
	
	WebDriver driver;
	
  @Test
  public void replacedriver()throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();

		EventFiringWebDriver driven = new EventFiringWebDriver(driver);
		EventHandler handle = new EventHandler();
		driven.register(handle);
		 driver.get("https://opensource-demo.orangehrmlive.com/");

		//driven.findElement(By.id("txtUsername")).sendKeys("Admin");
		//driven.findElement(By.id("txtPassword")).sendKeys("admin123");
		//driven.findElement(By.id("btnLogin")).click();
		 driven.findElement(By.name("txtUsername")).sendKeys("Admin");
		   driven.findElement(By.name("txtPassword")).sendKeys("admin123");
		   driven.findElement(By.name("Submit")).click();
  }
}
