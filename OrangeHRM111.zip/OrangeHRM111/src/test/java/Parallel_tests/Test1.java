package Parallel_tests;

import org.testng.annotations.Test;

public class Test1 {
  @Test
  public void f() {
  }
}
