package Github;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class github_login {
	
	WebDriver driver;
  @Test
  public void LoginTest() throws Exception
  
  {
	  
	  System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
		driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://github.com/");

		driver.findElement(By.xpath("/html/body/div[1]/header/div/div[2]/div[2]/div[2]/a")).click();
		//driver.findElement(By.xpath("/html/body/div[1]/header/div/div/div/a")).click();
		driver.findElement(By.id("login_field")).sendKeys("gmaruthisai.369@gmail.com");
		driver.findElement(By.id("password")).sendKeys("MBai@369");
		driver.findElement(By.name("commit")).click();

  }
  
  
}
