package Parallel_Methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class Test_methods {
  
	WebDriver driver;
  @Test
	public void OrangeHRM() throws Exception {
		
		WebDriver driver;
		
		//OpenChromeVrowser
		driver = TestBrowser.OpenChromeBrowser();
		
		//OpenUrl
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
		driver.findElement(By.name("txtUsername")).sendKeys("Admin");
		driver.findElement(By.name("txtPassword")).sendKeys("admin123");
		
		driver.quit();
	}
	
	
	@Test
	public void Mercury() throws Exception {
		
		WebDriver driver;
		
		//OpenChromeVrowser
		driver = TestBrowser.FirefoxBrowser();
		
		//OpenUrl
		driver.get("http://google.co.in");

		//SendKeys
		
		
		//Close Browser		
		driver.quit();
	}
	
	
	
}                                                  


