package page_object_model;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class Addingnationalities {
	
	WebDriver driver;
	
@BeforeTest
	
	public void browser() throws Exception
	{
		driver = TestBrowser.OpenChromeBrowser();
		String TestURL = "https://opensource-demo.orangehrmlive.com/";
		driver.get(TestURL);
		
	}
  @Test
  public void nationalitytest() throws Exception
  {
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
		/*Openchrome L1 = new Openchrome();
		L1.Openbrowser(driver);
		L1.openChromeLogin();*/
		
		LoginTest L1 = new LoginTest();
		L1.LoginPage(driver);
		L1.Logintest1();
		
		Add_nationalities A1 = new Add_nationalities();
		A1.Nationalities(driver);
		A1.AddNationalities();
		
		LogoutPage O1 = new LogoutPage();
		O1.Logouttest(driver);
		O1.welcome();
		
		Quittest Q1 = new Quittest();
		Q1.Quit(driver);
		Q1.Quittohome();
		
		
	  
  }
}
