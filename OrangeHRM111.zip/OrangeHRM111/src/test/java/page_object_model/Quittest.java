package page_object_model;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class Quittest {
 WebDriver driver;
  public void Quit(WebDriver driver)
  {
	  this.driver = driver;
  }
  public void Quittohome() throws Exception
  {
	  driver.quit();
	  
  }
}
