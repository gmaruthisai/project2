package page_object_model;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;



public class LogoutPage {
	
	WebDriver driver;
  
  public void Logouttest(WebDriver driver)
  {
	  this.driver = driver;
  }
  
  public void welcome() throws Exception
  {
	  
	  findElement(By.id("welcome")).click();
	  Thread.sleep(5000);
	  	
		findElement(By.linkText("Logout")).click();
  }
  
  public   WebElement findElement(By by) throws Exception 
	{

		WebElement elem = driver.findElement(by);  
		
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		return elem;
	}
	

  
}
