package page_object_model;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginTest {
	
	WebDriver driver;
	
	public static String User = "txtUsername";
	public static String Pwd = "txtPassword";
	public static String Btn = "btnLogin";
	
	
	/* public void LoginPage(WebDriver driver)
	  {
		  this.driver = driver ;
	  }*/
	
	public void LoginPage(WebDriver driver)
	{
		this.driver= driver;
		
	}
  public void Logintest1() throws Exception
  {
	  findElement(By.name(User)).sendKeys("Admin");
		findElement(By.name(Pwd)).sendKeys("admin123");
		findElement(By.id(Btn)).click();
	  
  }
  public   WebElement findElement(By by) throws Exception 
  {

  	WebElement elem = driver.findElement(by);  
  	
  	if (driver instanceof JavascriptExecutor) 
  	{
  	 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
   
  	}
  	return elem;
  }
}
