package  Emailable_report;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.Reporter;
import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.annotations.*;

public class lab_2_ex
{
	
	static WebDriver driver;
	
	
	@BeforeTest
	public void Test1() throws Exception {
		
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
		driver =new ChromeDriver();
		driver.manage().window().maximize();	
		Reporter.log("Pass- BeforeTEST");
	}
	
	
	@Test
	public void Test2() throws Exception {
		
		
		String TestURL = "https://opensource-demo.orangehrmlive.com/";
		driver.get(TestURL);
	    Reporter.log("Pass- open Orangehrm1");
		
	    driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		Reporter.log("Pass- Enter User Name1");
		
		driver.findElement(By.id("txtPassword")).sendKeys("admin123");	
		Reporter.log("Pass- Enter Password1");
		
		driver.findElement(By.id("btnLogin")).click();
		Reporter.log("Pass- Click on Signin1");
	
	}
	
	
	
	@AfterTest
	public void Test3() throws Exception {
		
		Reporter.log("Pass- aFTERtEST");
		driver.close();
		
	}
	
	
	
	
	

}












