package Emailable_report;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class HRM_login_report {
	
	WebDriver driver;

  @Test
  public void HRMopen() throws Exception
  {
	  
	 

		//Launch Browser
				System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
				driver =new ChromeDriver();
				driver.manage().window().maximize() ;
				
				
				driver.get("https://opensource-demo.orangehrmlive.com/");
				
				
				Reporter.log("pass");
				
				driver.findElement(By.id("txtUsername")).sendKeys("Admin");
				
				Reporter.log("pass");
				
				driver.findElement(By.id("txtPassword")).sendKeys("admin123");
				Reporter.log("pass");
				
				driver.findElement(By.id("btnLogin")).click();
				Reporter.log("Fail");
				

				
				
  }
}
