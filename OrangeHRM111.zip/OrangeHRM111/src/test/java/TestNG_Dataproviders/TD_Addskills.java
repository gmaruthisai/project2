package TestNG_Dataproviders;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

import ExcelUtil.ExcelApiTest4;



public class TD_Addskills {
	
	

	 WebDriver driver;
	
	public static int iRow = 0;

	
	@Parameters({"Browser"})
	@BeforeTest
	public void OpenBrowser(String browser) throws Exception {


		if(browser.equalsIgnoreCase("Chrome")){
			driver = TestBrowser.OpenChromeBrowser();
			System.out.println("Chrome Browser Started :"+browser);
		}
		
		else if(browser.equalsIgnoreCase("IE")){
			driver = TestBrowser.OpenIEBrowser();
			
		}
		
		else if(browser.equalsIgnoreCase("FireFox")){
			driver = TestBrowser.OpenFirefoxBrowser1();
		
		}
		
		else
		{
			driver = TestBrowser.OpenChromeBrowser();
			System.out.println("Chrome Brwoser Started :"+browser);
		}
		
	}
	

	@DataProvider(name = "Excel_skills")
	public static Object[][] Authentication1() throws Exception {

		ExcelApiTest4 Skill = new ExcelApiTest4();
		Object[][] testObjArray = Skill.getTableArray("C:\\HTML Report\\OrangeHRM6\\DT_Addskills.xlsx", "Sheet1");
		System.out.println(testObjArray.length);
		return (testObjArray);
	}
	
	
	
	
	
  @Test(dataProvider="Excel_skills")
  
  public void Addskills1(String TestURL,String UserName,String Password,
			String Addskills,String AddDis) throws Exception
  {
	  if (iRow==0)
		{
			//iRow++;									//  first iteration taking irow=0--> irow=irow+1---> 1
			iRow=iRow+1;
			
				
			
			 driver.get(TestURL);
			 
			 
			Login(UserName,Password);
			 Addskills(Addskills,AddDis);
			
		}
	  else												// after execution of 1st iteration irow=1--> irow=irow+1---> 2
		{
			//iRow++;
			iRow=iRow+1;								//this time it will directly execute the only addskills
			
														//no need of login everytime so we are using if else condition here
			
			Addskills(Addskills,AddDis);
			
			
		}
		
 }
  @AfterTest
	/*public void CloseBrowser() throws Exception 
	{
		driver.quit();
	}
	*/
  public void Login(String UserName,String Password) throws Exception
  {
	  	findElement(By.id("txtUsername")).sendKeys(UserName);
		findElement(By.id("txtPassword")).sendKeys(Password);
		findElement(By.id("btnLogin")).click();
		
  }
	  public void Addskills(String Addskills,String AddDis) throws Exception
	  {
		    findElement(By.id("menu_admin_viewAdminModule")).click();
			findElement(By.id("menu_admin_Qualifications")).click();
			findElement(By.id("menu_admin_viewSkills")).click();

			findElement(By.id("btnAdd")).click();
			findElement(By.id("skill_name")).sendKeys(Addskills);
			findElement(By.id("skill_description")).sendKeys(AddDis);
			findElement(By.id("btnSave")).click();
			
		  
	  }
  
	  public WebElement findElement(By by) throws Exception {
			WebElement elem = driver.findElement(by);

			if (driver instanceof JavascriptExecutor) {
				((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid red'", elem);
			}
			Thread.sleep(10);

			return elem;
		}
}
