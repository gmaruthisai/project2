package drop_tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Practice_session {
	
	WebDriver driver;
	
	@Test
	public void practice() throws Exception
	{
		  System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
			driver =new ChromeDriver();
			driver.manage().window().maximize() ;	
			driver.get("https://opensource-demo.orangehrmlive.com/");
		
		//driver.findElement(By.className("whsOnd zHQkBf")).sendKeys("maruthisai.369@gmail.com");
		//driver.findElement(By.className("VfPpkd-vQzf8d")).click();
		//driver.findElement(By.className("password")).sendKeys("");
		//driver.findElement(By.className("VfPpkd-vQzf8d")).click();
		
	}

}
