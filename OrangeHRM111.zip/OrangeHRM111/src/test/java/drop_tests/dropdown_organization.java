package drop_tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class dropdown_organization {

	static WebDriver driver;
	

	@Test
	public void practice() throws Exception
	{
		  System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
			driver =new ChromeDriver();
			driver.manage().window().maximize() ;	
			driver.get("https://opensource-demo.orangehrmlive.com/");
		
	
	driver.findElement(By.id("txtUsername")).sendKeys("Admin");
	driver.findElement(By.id("txtPassword")).sendKeys("admin123");
	driver.findElement(By.id("btnLogin")).click();
	
	driver.findElement(By.id("menu_admin_viewAdminModule")).click();
	driver.findElement(By.id("menu_admin_Organization")).click();
	driver.findElement(By.id("menu_admin_viewLocations")).click();
	
	Select dropdown1 = new Select(driver.findElement(By.id("searchLocation_country")));
	dropdown1.selectByIndex(6);
	
	
	
	driver.findElement(By.id("btnAdd")).click();
	Select dropdown2 = new Select(driver.findElement(By.id("location_country")));
	dropdown2.selectByIndex(3);

	}
}
	
