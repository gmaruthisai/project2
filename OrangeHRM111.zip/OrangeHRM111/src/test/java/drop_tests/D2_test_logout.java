package drop_tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class D2_test_logout {
	
	WebDriver driver;
  @Test
  public void Logout() throws Exception
  {
	  driver= TestBrowser.OpenChromeBrowser();
	  driver.get("https://opensource-demo.orangehrmlive.com/");
	  
	  driver.findElement(By.id("txtUsername")).sendKeys("Admin");
	  driver.findElement(By.id("txtPassword")).sendKeys("admin123");
	  driver.findElement(By.id("btnLogin")).click();
	  
	  driver.findElement(By.id("menu_admin_viewAdminModule")).click();
	  driver.findElement(By.id("menu_admin_UserManagement")).click();
	  driver.findElement(By.id("menu_admin_viewSystemUsers")).click();
	  
	  Select drop1 =new Select(driver.findElement(By.id("searchSystemUser_userType")));
	  
	  drop1.selectByVisibleText("ESS");
	  
	 
	  
	  Select drop2 =new Select(driver.findElement(By.id("searchSystemUser_status")));
	  
	  drop2.selectByIndex(1);
	  
		
	  
  }
}
