package drop_tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class Katalon_addskills {
 
	  
	  WebDriver driver;
	  
		@Test
		public  void record() throws Exception

		
		{
			
			driver = TestBrowser.OpenChromeBrowser();
			
			 driver.get("https://opensource-demo.orangehrmlive.com/");
			  
			    driver.findElement(By.id("txtUsername")).sendKeys("Admin");
			   
			     driver.findElement(By.id("txtPassword")).sendKeys("admin123");
			    driver.findElement(By.id("btnLogin")).click();
			    driver.findElement(By.xpath("//a[@id='menu_admin_viewAdminModule']/b")).click();
			    driver.findElement(By.id("menu_admin_Qualifications")).click();
			    driver.findElement(By.id("menu_admin_viewSkills")).click();
			    driver.findElement(By.id("btnAdd")).click();
			    driver.findElement(By.id("skill_name")).click();
			 
			    driver.findElement(By.id("skill_name")).sendKeys("skill1");
			    
			    driver.findElement(By.id("skill_description")).sendKeys("skill1descrr");
			    driver.findElement(By.id("btnSave")).click();
			
		}


	

  }

