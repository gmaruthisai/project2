package Take_Screenshots;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class Addjobs {
	
	WebDriver driver;
  @Test
  public void shot() throws Exception
  
  {
		driver = TestBrowser.OpenChromeBrowser();
		driver.get("https://opensource-demo.orangehrmlive.com/");
		TakesScreenshot shot1 = ((TakesScreenshot) driver);
		File filE1 = shot1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(filE1, new File("D:\\takescreenshots2\\Add_nations1.jpg"));

		findElement(By.id("txtUsername")).sendKeys("Admin");
		//shot1 = ((TakesScreenshot) driver);
		File filE2 = shot1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(filE2, new File("D:\\takescreenshots2\\Add_nations2.jpg"));

		findElement(By.id("txtPassword")).sendKeys("admin123");
		//shot1 = ((TakesScreenshot) driver);
		File filE3 = shot1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(filE3, new File("D:\\takescreenshots2\\Add_nations3.jpg"));

		findElement(By.id("btnLogin")).click();
		//shot1 = ((TakesScreenshot) driver);
		File filE4 = shot1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(filE4, new File("D:\\takescreenshots2\\Add_nations4.jpg"));

		findElement(By.id("menu_admin_viewAdminModule")).click();
		//shot1 = ((TakesScreenshot) driver);
		File filE5 = shot1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(filE5, new File("D:\\takescreenshots2\\Add_nations5.jpg"));

		findElement(By.id("menu_admin_Job")).click();
		//shot1 = ((TakesScreenshot) driver);
		File filE6 = shot1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(filE6, new File("D:\\takescreenshots2\\Add_nations6.jpg"));

		findElement(By.id("menu_admin_viewJobTitleList")).click();
		//shot1 = ((TakesScreenshot) driver);
		File filE7 = shot1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(filE7, new File("D:\\takescreenshots2\\Add_nations7.jpg"));

		findElement(By.id("btnAdd")).click();
		//shot1 = ((TakesScreenshot) driver);
		File filE8 = shot1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(filE8, new File("D:\\takescreenshots2\\Add_nations8.jpg"));

		findElement(By.id("jobTitle_jobTitle")).sendKeys("jobTitle_jobTitle1");
		//shot1 = ((TakesScreenshot) driver);
		File filE9 = shot1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(filE9, new File("D:\\takescreenshots2\\Add_nations9.jpg"));

		findElement(By.id("jobTitle_jobDescription")).sendKeys("jobTitle_jobDescription1");
		//shot1 = ((TakesScreenshot) driver);
		File filE10 = shot1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(filE10, new File("D:\\takescreenshots2\\Add_nations10.jpg"));

		findElement(By.id("jobTitle_note")).sendKeys("jobTitle_note1");
		//shot1 = ((TakesScreenshot) driver);
		File filE11 = shot1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(filE11, new File("D:\\takescreenshots2\\Add_nations11.jpg"));

		findElement(By.id("btnSave")).click();
		//shot1 = ((TakesScreenshot) driver);
		File filE12 = shot1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(filE12, new File("D:\\takescreenshots2\\Add_nations12.jpg"));

	  
	  
	  
	  
  }
  public WebElement findElement(By by) throws Exception 
	{
				
		 WebElement elem = driver.findElement(by);    	    
		
		 
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		
		return elem;
	}

}
