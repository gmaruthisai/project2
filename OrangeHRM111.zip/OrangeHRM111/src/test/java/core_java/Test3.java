package core_java;

public class Test3 implements Intclass,Int2class {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub

	}

	
	@Override
	public void Launch() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void hello() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void Browse() {
		// TODO Auto-generated method stub
		
	}

}
