package core_java;

public interface Int2class {

	
	public abstract void Browse();
}
