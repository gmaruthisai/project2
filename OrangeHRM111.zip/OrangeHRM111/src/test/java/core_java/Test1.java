package core_java;

public class Test1 extends Absclass {

	public static void main(String[] args) {
		
		Absclass A1 = new Test1();
		A1.Login();

	}

	@Override
	public void Login() {
		// TODO Auto-generated method stub
		System.out.println("null");
	}
	


	

}
