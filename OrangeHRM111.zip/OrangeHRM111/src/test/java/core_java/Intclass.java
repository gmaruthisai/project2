package core_java;

public interface Intclass {
	
	public abstract void Launch();
	
	public  void hello();

}
