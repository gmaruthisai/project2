package core_java;

public class Test2 implements Intclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void Launch() {
		System.out.println("hfhkja");
		
	}

	@Override
	public void hello() {
		// TODO Auto-generated method stub
		
	}

}
