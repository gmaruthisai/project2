package core_java;

public abstract class Abs2class {

	public abstract void Nest();
}
