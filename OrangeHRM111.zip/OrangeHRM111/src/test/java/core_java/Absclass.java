package core_java;

public abstract class Absclass {

	public abstract void Login();
	

	public static void main(String[] args)
	{
		
	}
}
