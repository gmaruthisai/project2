package Action_class;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Drag_Drop {
	
	WebDriver driver;
  @Test
  public void Test() throws Exception
  {
	  
	  System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
		driver =new ChromeDriver();
		driver.manage().window().maximize() ;	
		driver.get("https://www.globalsqa.com/demo-site/draganddrop/");
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
		findElement(By.id("Photo Manager")).click();
		driver.switchTo().frame(findElement(By.className("post-2669 page type-page status-publish hentry")));
		
		
		
		
		driver.switchTo().frame(findElement(By.xpath("/html")));
		
		
		WebElement Source_Drag_Button=findElement(By.xpath("//*[@id=\'gallery\']/li[1]/img"));
		WebElement Target_Drag_Button=findElement(By.id("trash"));
		
		Actions actions = new Actions(driver);
		
		actions.dragAndDrop(Source_Drag_Button, Target_Drag_Button).perform();

	  
  }
  
  public  WebElement findElement(By by) throws Exception 
	{

		WebElement elem = driver.findElement(by);  
		
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		return elem;
	}
}
