package Encapsulation;


class Myclass1
{
	int empid;
	String empname;
	String cityname;
	
	public void setEmpid(int em)
	{
		empid = em;
	}
	
	public int getEmpid()
	{
		return empid;
	}
	
	
	
	public void setEmpname(String name) 
	{
		empname = name;
	}
	
	public String getEmpname()
	{
		return empname;
	}
	
	public void setCityname(String S)
	{
		cityname = S;
	}
	public String getCityname()
	{
		return cityname;
	}
	
}

public class Test2 {

	public static void main(String[] args) {
		
		Myclass1 M1 = new Myclass1();
		M1.setEmpid(32);
		M1.setEmpname("Maruthi");
		M1.setCityname("Sangareddy");
		
		System.out.println("The Identity number-" +M1.getEmpid());
		System.out.println("The candidate Name-" +M1.getEmpname());
		System.out.println("City name-" +M1.getCityname());
		

	}

}
