package Encapsulation;

class Myclass
{
	int empid;
	String empname;
	
}

public class Test1 {

	public static void main(String[] args) {
		
		
		

	}

}
