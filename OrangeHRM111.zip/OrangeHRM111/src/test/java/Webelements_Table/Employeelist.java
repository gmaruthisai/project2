package Webelements_Table;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import ExcelUtil.ExcelApiTest3;

public class Employeelist {
	WebDriver driver;
  @Test
  public void list1()throws Exception
  {
	  
	  System.setProperty("webdriver.chrome.driver", "C:\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/");

		findElement(By.id("txtUsername")).sendKeys("Admin");
		findElement(By.id("txtPassword")).sendKeys("admin123");
		findElement(By.id("btnLogin")).click();
		
		findElement(By.id("menu_pim_viewPimModule")).click();
		findElement(By.id("menu_pim_viewEmployeeList")).click();
		
  }
  @Test
  public void emplist() throws Exception
	{
		String Empcoloums = "//*[@id='resultTable']/thead/tr/th";    //*[@id='resultTable']/thead/tr/th
		List<WebElement> columns = driver.findElements(By.xpath(Empcoloums));

		String Emprows = "//*[@id='resultTable']/tbody/tr/td[2]";    //"//*[@id='resultTable']/tbody/tr[2]/td[2]"
		List<WebElement> rows = driver.findElements(By.xpath(Emprows));

		ExcelApiTest3 Listemp = new ExcelApiTest3();

		for (int i = 1; i <= rows.size(); i++) // i=1; i<=7 ; i=i+1
		{
			for (int j = 2, k = 0; j <= columns.size(); j++, k++) // j=2 ; J<=8 ; j++
			{

				String str1 = "//*[@id='resultTable']/tbody/tr[" + i + "]" + "/td" + "[" + j + "]";

				WebElement Ele = findElement(By.xpath(str1));

				String WebElementText = Ele.getText();
				// System.out.println("Get Text Value is from the WebElement: " + valueIneed1);

				if (WebElementText != null)
					Listemp.PutCellData("C:\\HTML Report\\OrangeHRM6\\TC01_AddEmp.xls", "Sheet4", i, k, WebElementText);
				else
					Listemp.PutCellData("C:\\HTML Report\\OrangeHRM6\\TC01_AddEmp.xls", "Sheet4", i, k, "Blank Data");

			}
		}

	}
  public WebElement findElement(By by)throws Exception
  {
	    WebElement elem = driver.findElement(by);
	 
	    // draw a border around the found element
	    if (driver instanceof JavascriptExecutor) {
	        ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid green'", elem);
	    } 
	    Thread.sleep(10);
	    
	    return elem;
	
  }
  }
  

