package Webelements_Table;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import ExcelUtil.ExcelApiTest3;
import ExcelUtil.ExcelApiTest4;

public class vacancies {
	
	//int i;
	//int j;
	//int k;
	WebDriver driver;
  @Test
  public void Login() throws Exception
  {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/");

		findElement(By.id("txtUsername")).sendKeys("Admin");
		findElement(By.id("txtPassword")).sendKeys("admin123");
		findElement(By.id("btnLogin")).click();
		
		findElement(By.id("menu_recruitment_viewRecruitmentModule")).click();
		findElement(By.id("menu_recruitment_viewJobVacancy")).click();
	  
  }
  @Test
  public void vacanciestable() throws Exception//*[@id="resultTable"]/thead/tr/th[2]/a
  {
	  String Empcoloums=" //*[@id='resultTable']/thead/tr/th";//*[@id="resultTable"]/tbody/tr[1]/td[2]/a  //for selecting columns inspecting the header for xpath
		 List<WebElement>  columns = driver.findElements(By.xpath(Empcoloums));
		 
		 String EmpRows="//*[@id='resultTable']/tbody/tr/td[2]";//*[@id='resultTable']/tbody/tr[3]/td[2]  //for selecting row take any cell value in the table
	        List<WebElement>   rows = driver.findElements(By.xpath(EmpRows)); 
	  
	        ExcelApiTest3 object = new ExcelApiTest3();
	        
	      /*  for ( int i=1 ; i<=rows.size() ;i++)  // i=1;  i<=7 ; i=i+1
		    {
		    	  for ( int j=2 ,k=0; j<=columns.size() ;j++,k++) //j=2 ; J<=8 ; j++
		    	   {*/
		for (int j = 2, k = 0; j <= columns.size(); j++, k++) // i=1; i<=7 ; i=i+1
		{
			for (int i = 1; i <= rows.size(); i++) // j=2 ; J<=8 ; j++
			{
	        
	        /* for (j=2 ; j<=4; j++);
	         {
	        	 for ( i=1;  i<=7 ; i=i+1);
	        			 {*/
				String str1 = "//*[@id='resultTable']/tbody/tr[" + i + "]" + "/td" + "[" + j + "]";

				WebElement Ele = findElement(By.xpath(str1));

				String WebElementText = Ele.getText();
				// System.out.println("Get Text Value is from the WebElement: " + valueIneed1);

				if (WebElementText != null)
					object.PutCellData("C://HTML Report//OrangeHRM6//TC01_EMPExport.xls", "Sheet5", i, k,
							WebElementText);
				else
					object.PutCellData("C://HTML Report//OrangeHRM6//TC01_EMPExport.xls", "Sheet5", i, k, "Blank Data");

			}
		}
 		    
	      
	  
  
  }
  
  public WebElement findElement(By by)throws Exception
  {
	    WebElement elem = driver.findElement(by);
	 
	    // draw a border around the found element
	    if (driver instanceof JavascriptExecutor) {
	        ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid green'", elem);
	    } 
	    Thread.sleep(10);
	    
	    return elem;
	
  } 
}
