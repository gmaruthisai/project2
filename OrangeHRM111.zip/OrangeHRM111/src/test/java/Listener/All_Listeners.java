package Listener;

import org.testng.ITestListener;

public class All_Listeners implements ITestListener {

}
