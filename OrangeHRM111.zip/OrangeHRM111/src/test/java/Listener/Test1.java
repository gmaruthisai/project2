package Listener;

import org.testng.ITestListener;
import org.testng.annotations.Test;

public class Test1 implements ITestListener {
 
}
