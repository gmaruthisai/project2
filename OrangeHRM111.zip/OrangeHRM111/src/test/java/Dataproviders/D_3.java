package Dataproviders;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ExcelUtil.ExcelApiTest4;

public class D_3 {
	
	 WebDriver driver;
		
	 @DataProvider(name= "Addjobs_Excel")
	 
	 public static Object[][] authentication() throws Exception
		 {
				
				ExcelApiTest4 data3 = new ExcelApiTest4();
				Object[][] testObjArray = data3.getTableArray("C:\\HTML Report\\OrangeHRM6\\TC01_Jobs81.xlsx\\", "Sheet1");
				System.out.println(testObjArray.length);
				return (testObjArray);
			
	 }
	 
		 
		 @Test(dataProvider="Addjobs_Excel")
		 public void data3(String Browser,String URL,String UserName1,String Password1,String JobTitle,String JobDesc,String JobNote) throws Exception
	 {
		 
			 D_3 T1=new D_3();
				
				
				if(Browser.equalsIgnoreCase("Chrome"))
				{
			
				 	T1.OpenChromeBroswer1();
			    }

				if(Browser.equalsIgnoreCase("FireFox"))
				{
						T1.FireFoxBrowser();
				}
				
				T1.OpenHRM(URL);
				T1.Login(UserName1,Password1);
				T1.AddJob(JobTitle,JobDesc,JobNote);
				T1.CloseBrowser();
	 }
		 
		 public  void OpenChromeBroswer1() throws Exception
			{
				System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
				driver =new ChromeDriver();
				driver.manage().window().maximize() ;	
				
			}
			
			
			public  void FireFoxBrowser() throws Exception
			{
				 System.setProperty("webdriver.gecko.driver","C:\\FireFoxDriver\\geckodriver.exe");
				 driver = new FirefoxDriver();
				 Thread.sleep(6000);
				 driver.manage().window().maximize() ;	
				
			}
			
			
			public void OpenHRM(String URL)throws Exception
			{
				driver.get(URL);
			}
			

			public   void Login(String UserName,String Password) throws Exception //step3
			{
				findElement(By.id("txtUsername")).sendKeys(UserName);  //step4
				findElement(By.id("txtPassword")).sendKeys(Password);  //step4
				findElement(By.id("btnLogin")).click();
			}
			

			public  void AddJob(String JobTitle,String JobDesc,String JobNote) throws Exception
			{
				findElement(By.id("menu_admin_viewAdminModule")).click();
				findElement(By.id("menu_admin_Job")).click();
				findElement(By.id("menu_admin_viewJobTitleList")).click();
				findElement(By.id("btnAdd")).click();
				findElement(By.id("jobTitle_jobTitle")).sendKeys(JobTitle);
				findElement(By.id("jobTitle_jobDescription")).sendKeys(JobDesc);
				findElement(By.id("jobTitle_note")).sendKeys(JobNote);//step4
				findElement(By.id("btnSave")).click();
			}
			

			public  void CloseBrowser() throws Exception
			{
				driver.quit();
			}
			



public  WebElement findElement(By by) throws Exception 
{

	WebElement elem = driver.findElement(by);  
	
	if (driver instanceof JavascriptExecutor) 
	{
	 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
 
	}
	return elem;
}
}

