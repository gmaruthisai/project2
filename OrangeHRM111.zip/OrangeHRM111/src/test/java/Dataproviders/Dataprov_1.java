package Dataproviders;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Dataprov_1 {
	
	static WebDriver driver;				
	
	
	@DataProvider(name = "first_method")
	
		public static Object[][] myfirstmethod() throws Exception		//[][]-->array object
		{
		return new Object[][] {
			
			{ "https://opensource-demo.orangehrmlive.com/","Admin", "admin123","JObtitle1","Jobdesr1","Jobnote1" },
			{ "https://opensource-demo.orangehrmlive.com/","Admin", "admin123","JObtitle2","Jobdesr2","Jobnote2"},
			{ "https://opensource-demo.orangehrmlive.com/","Admin", "admin123","JObtitle","Jobdesr3","Jobnote3" },
			
		};
		
		
		
		}
	
	
	
	
	
  @Test(dataProvider= "first_method")
  public void test7(String TestURL,String username ,String password ,String jobTitle_jobTitle ,String jobTitle_jobDescription,String jobTitle_note ) throws Exception
  {
	  Dataprov_1 mainobject =new Dataprov_1();		//classname object = new classname
	  
	  mainobject.OpenChromeBrowser();				//classname.methodname()	//string TestURL, username,pass..are the Global variables
	  mainobject.OpenOrangeHRM(TestURL);
	  mainobject.Login(username,password);
	  mainobject.AddJobs(jobTitle_jobTitle,jobTitle_jobDescription,jobTitle_note);
	  //T_6.CloseBrowser();
	  
  }
	 
		
		public void OpenChromeBrowser() throws Exception		
		
		{
			System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32\\chromedriver.exe");
			driver =new ChromeDriver();
			driver.manage().window().maximize() ;	
				
		}
		
		public void OpenOrangeHRM(String TestURL1) throws Exception		//TestURL1 is a local variable
		
		{
			 driver.get(TestURL1);	
		}
		
		
		public void Login(String username1,String password1) throws Exception		
		
		{
			findElement(By.id("txtUsername")).sendKeys(username1);
			findElement(By.id("txtPassword")).sendKeys(password1);
			findElement(By.id("btnLogin")).click();
			
		}
		public  void AddJobs(String jobTitle_jobTitle,String jobTitle_jobDescription,String jobTitle_note) throws Exception		
		
		{
			findElement(By.id("menu_admin_viewAdminModule")).click();
			findElement(By.id("menu_admin_Job")).click();
			findElement(By.id("menu_admin_viewJobTitleList")).click();
			findElement(By.id("btnAdd")).click();
			findElement(By.id("jobTitle_jobTitle")).sendKeys(jobTitle_jobTitle);
			findElement(By.id("jobTitle_jobDescription")).sendKeys(jobTitle_jobDescription);
			findElement(By.id("jobTitle_note")).sendKeys(jobTitle_note);
			findElement(By.id("btnSave")).click();
		}
		public void CloseBrowser() throws Exception		
		
		{
			driver.quit();
		}
		
  
  public WebElement findElement(By by) throws Exception 
	{

		WebElement elem = driver.findElement(by);  
		
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		return elem;
	}
  
}
