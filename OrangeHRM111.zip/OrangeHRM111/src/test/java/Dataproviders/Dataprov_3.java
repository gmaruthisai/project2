package Dataproviders;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import ExcelUtil.ExcelApiTest3;
import ExcelUtil.ExcelApiTest4;


public class Dataprov_3 {
	
	 WebDriver driver;
	
@DataProvider(name= "Addnationalities_Excel")
	
public static Object[][] Authentication1() throws Exception {
		
		ExcelApiTest3 data3 = new ExcelApiTest3();
		Object[][] testObjArray = data3.getTableArray("C:\\HTML Report\\OrangeHRM6\\TC01_Nationality.xls", "Sheet2");
		System.out.println(testObjArray.length);
		return (testObjArray);
	}
	@Test(dataProvider="Addnationalities_Excel")
	public void loginTest(String Browser,String URL,String UserName,String Password,String Nationality_text ) throws Exception //Step2
	{
		
		Dataprov_3 T1=new Dataprov_3();
		
		
		if(Browser.equalsIgnoreCase("Chrome"))
		{
	
		 	T1.OpenChromeBroswer();
	    }

		if(Browser.equalsIgnoreCase("FireFox"))
		{
				T1.FireFoxBrowser();
		}
		
		//T1.OpenChromeBroswer();
		T1.OpenOrangeHRM(URL);
		T1.Login(UserName,Password); //step2
		T1.AddNationalities(Nationality_text);//stp2
		T1.CloseBrowser();
	}
	
	
	public  void OpenChromeBroswer() throws Exception
	{
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
		driver =new ChromeDriver();
		driver.manage().window().maximize() ;	
		
	}
	
	
	public  void FireFoxBrowser() throws Exception
	{
		 System.setProperty("webdriver.gecko.driver","C:\\FireFoxDriver\\geckodriver.exe");
		 driver = new FirefoxDriver();
		 Thread.sleep(6000);
		 driver.manage().window().maximize() ;	
		
	}
	
	
	public void OpenOrangeHRM(String URL)throws Exception
	{
		driver.get(URL);
	}
	

	public   void Login(String UserName,String Password) throws Exception //step3
	{
		findElement(By.id("txtUsername")).sendKeys(UserName);  //step4
		findElement(By.id("txtPassword")).sendKeys(Password);  //step4
		findElement(By.id("btnLogin")).click();
	}
	

	public  void AddNationalities(String Nationality_text) throws Exception
	{
		findElement(By.id("menu_admin_viewAdminModule")).click();
		findElement(By.id("menu_admin_nationality")).click();
		findElement(By.id("btnAdd")).click();
		findElement(By.id("nationality_name")).sendKeys(Nationality_text);//step4
		findElement(By.id("btnSave")).click();
	}
	

	public  void CloseBrowser() throws Exception
	{
		driver.quit();
	}
	

	
	
	
	
	public  WebElement findElement(By by) throws Exception 
	{

		WebElement elem = driver.findElement(by);  
		
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		return elem;
	}
	
	
	
	
	
	
	
}
