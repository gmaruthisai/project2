package customizable_report;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import CommonUtil.OR;
import CommonUtil.TestBrowser;
import ExcelUtil.ExcelApiTest4;
import customizable_report.Reporter1;

public class AddJobs_Customizable {
	
	WebDriver driver;
	Reporter1 R1;
	public static int iRow = 0;
	
	@Parameters({"Browser"})
	@BeforeTest
	public void OpenBrowser(String browser) throws Exception {


		if(browser.equalsIgnoreCase("Chrome")){
			driver = TestBrowser.OpenChromeBrowser();
			System.out.println("Chrome Brwoser Started :"+browser);
		}
		
		else if(browser.equalsIgnoreCase("IE")){
			driver = TestBrowser.OpenIEBrowser();
			
		}
		
		else if(browser.equalsIgnoreCase("FireFox")){
			driver = TestBrowser.OpenFirefoxBrowser();
		
		}
		
		else
		{
			driver = TestBrowser.OpenChromeBrowser();
			System.out.println("Chrome Brwoser Started :"+browser);
		}
		
	}

	@DataProvider(name = "Custom_Report")
	public static Object[][] Authentication1() throws Exception {

		ExcelApiTest4 Job = new ExcelApiTest4();
		Object[][] testObjArray = Job.getTableArray("C:\\HTML Report\\OrangeHRM6\\AddJobs_customizable.xlsx", "Sheet1");
		System.out.println(testObjArray.length);
		return (testObjArray);
	}
	
	@Test(dataProvider = "Custom_Report")
	public void Test3(String TestURL,String UserName,String Password,
			String JobTitle,String JobDescription,String JobNote ) throws Exception {
		
		if (iRow==0)
		{
			//iRow++;
			iRow=iRow+1;
			
			String str= "Test_AddJObs".concat("_Iterration_").concat(String.valueOf(iRow)) ;
			R1= new Reporter1(driver,str);	
			
			 driver.get(TestURL);
			 R1.TakeScreenShotAuto(driver,"Open chrome Browser and URL ","Pass");
			 
			 
			 Login(UserName,Password);
			 AddJobs(JobTitle,JobDescription,JobNote);
			 
		}
			 
			 else
				{
					//iRow++;
					iRow=iRow+1;
					
					String str= "Test_AddJObs".concat("_Iterration_").concat(String.valueOf(iRow)) ;
					R1= new Reporter1(driver,str);	
					
					AddJobs(JobTitle,JobDescription,JobNote);
					
					
		}
		
	}
		@AfterTest
		public void CloseBrowser() throws Exception 
		{
			driver.quit();
		}
		
		
		
		public void Login(String UserName,String Password) throws Exception 
		
		{
			
			findElement(By.xpath(OR.username_sendkey)).sendKeys(UserName);
			R1.TakeScreenShotAuto(driver,"UserName Entered","Pass");
		
			
			findElement(By.xpath(OR.password_sendkey)).sendKeys(Password);
			R1.TakeScreenShotAuto(driver,"Password Entered","Pass");

			findElement(By.xpath(OR.login_click)).click();
			R1.TakeScreenShotAuto(driver,"Sign In  Clicked","Pass");

		
		}
		
		
		public void AddJobs(String JobTitle,String JobDescription,String JobNote) throws Exception {
		
		 findElement(By.xpath(OR.Admin_focus));
		 R1.TakeScreenShotAuto(driver,"Clicked on Admin ","Pass");
		 
		 findElement(By.xpath(OR.Admin_focus)).click();
		 
		 findElement(By.id("menu_admin_Job"));
		 R1.TakeScreenShotAuto(driver,"Clicked on Jobs ","Pass");
		 findElement(By.id("menu_admin_Job")).click();

		 findElement(By.id("menu_admin_viewJobTitleList"));
		 R1.TakeScreenShotAuto(driver,"Clicked on jobtitle ","Pass");
		 findElement(By.id("menu_admin_viewJobTitleList")).click();
		 
		 findElement(By.name("btnAdd"));
		 R1.TakeScreenShotAuto(driver,"Clicked on jobtitle ","Pass");
		 findElement(By.name("btnAdd")).click();
		 
		 findElement(By.id("jobTitle_jobTitle")).sendKeys(JobTitle);
		 R1.TakeScreenShotAuto(driver,"Clicked on jobtitle ","Pass");
		 
		 
		 findElement(By.id("jobTitle_jobDescription")).sendKeys(JobDescription);
		 R1.TakeScreenShotAuto(driver,"Entered jobDescription","Pass");
		 
		 findElement(By.id("jobTitle_note")).sendKeys(JobNote);
		 R1.TakeScreenShotAuto(driver,"Entered Jobnote","Pass");
		 
		 findElement(By.id("btnSave"));
		 R1.TakeScreenShotAuto(driver,"Clicked on Save ","Pass");
		 findElement(By.id("btnSave")).click();
		 
		 
		//WebElement Element2 = findElement(By.id(menu_admin_Job));
		
		//JavascriptExecutor js = (JavascriptExecutor) driver;
		//js.executeScript("arguments[0].scrollIntoView();", Element2);
		
		//R1.TakeScreenShotAuto(driver,"Scroll Nationality ","Pass");
		
		}
		
		

	

	public WebElement findElement(By by) throws Exception {
		WebElement elem = driver.findElement(by);

		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid red'", elem);
		}
		Thread.sleep(10);

		return elem;
	}
	
	
	

	
	
	
	


	
	
	
}
