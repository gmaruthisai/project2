package customizable_report;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;
import customizable_report.Reporter1;	//package.classname

public class New_report {

	static WebDriver driver;
	Reporter1 R1;
	
	@Test
	public void login_report() throws Exception
	{
		driver = TestBrowser.OpenChromeBrowser();
		
		String str= "Data_Head";
		R1= new Reporter1(driver,str);	
		
		String TestURL = "https://opensource-demo.orangehrmlive.com/";
		
		driver.get(TestURL);
		R1.TakeScreenShotAuto(driver,"Opened Orange HRM","Pass");
		 
	   
		findElement(By.id("txtUsername")).sendKeys("Admin");
		R1.TakeScreenShotAuto(driver,"Username Entered","Pass");
		

		findElement(By.id("txtPassword")).sendKeys("admin123");	
		R1.TakeScreenShotAuto(driver,"Password Entered","Fail");
		
		
		findElement(By.name("Submit")).click();
		R1.TakeScreenShotAuto(driver,"Clicked on Signin","Fail");
		driver.close();
		
		
	}
	
	public  WebElement findElement(By by) throws Exception 
	{
				
		 WebElement elem = driver.findElement(by);    	    
		// draw a border around the found element
		 
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		
		return elem;
	}
}
