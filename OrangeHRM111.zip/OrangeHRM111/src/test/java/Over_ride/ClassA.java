package Over_ride;


class myclass 
{
	public void Family()
	
	{
		System.out.println("Parent");
	}
}


class myotherclass extends myclass
{
	//@Override
	public void Family()
	{
		//super.Family();					// super.methodname is given to print both 
		System.out.println("child");
	}

}

public class ClassA {
	
	public static void main(String[] args) {
	
		myotherclass F1 = new myotherclass();     // child class overrides the parent class
		F1.Family();
		
		//myclass m1 = new myclass();					//parent class overrides the child class
		//m1.Family();
		
	}
	

}
