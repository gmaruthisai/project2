package File_explorer;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import CommonUtil.OR;
import CommonUtil.TestBrowser;
import ExcelUtil.ExcelApiTest4;

public class File_upload {
	
	static WebDriver driver;
	
@DataProvider(name= "Addprofilepic")
	
	public Object [][] mydataprovider() throws Exception
	{
		
		ExcelApiTest4 file = new ExcelApiTest4();
		Object [][] testObjarray = file.getTableArray("C:\\\\HTML Report\\\\OrangeHRM6\\\\AddJobs_customizable.xlsx", "Sheet2");
		System.out.println(testObjarray.length);
	return (testObjarray);
		
		
		
	}
  
	  @Test (dataProvider = "Addprofilepic")
	  public void Addphoto(String UserName, String Password, String Filepath, String JobTitle,String JobDesc,String JobNote ) throws Exception
	  {
		  driver = TestBrowser.OpenChromeBrowser();
		  driver.get("https://opensource-demo.orangehrmlive.com/");
		  
		  driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			 
		  	 findElement(By.xpath(OR.username_sendkey)).sendKeys(UserName);
			 findElement(By.xpath(OR.password_sendkey)).sendKeys(Password);
			 findElement(By.xpath(OR.login_click)).click();
			 
			 findElement(By.xpath(OR.Admin_focus)).click();
			 findElement(By.id("menu_admin_Job")).click();
			 findElement(By.id("menu_admin_viewJobTitleList")).click();
			 findElement(By.name("btnAdd")).click();
			 
			 findElement(By.id("jobTitle_jobTitle")).sendKeys(JobTitle);
			 findElement(By.id("jobTitle_jobDescription")).sendKeys(JobDesc);
			 findElement(By.id("jobTitle_note")).sendKeys(JobNote);
			 
			 WebElement button =findElement(By.id("jobTitle_jobSpec"));
				
			 Actions actions = new Actions(driver);
		  	actions.moveToElement(button).click().build().perform();
		  	
		  	Thread.sleep(5000);
			 
			 
			FileUpload(Filepath);
			 
	  
  }
	  public void FileUpload(String Filepath) throws Exception
	  {
		  	 StringSelection sel = new StringSelection(Filepath);
			 Toolkit.getDefaultToolkit().getSystemClipboard().setContents(sel,null);
			
			 Robot robot = new Robot();
			 
			 robot.keyPress(KeyEvent.VK_CONTROL);
			 robot.keyPress(KeyEvent.VK_V);
			 
			
			 robot.keyRelease(KeyEvent.VK_CONTROL);
			 robot.keyRelease(KeyEvent.VK_V);
			 Thread.sleep(2000);
			        
			        
			 robot.keyPress(KeyEvent.VK_ENTER);
			 robot.keyRelease(KeyEvent.VK_ENTER);
			 Thread.sleep(8000);
			 
			 findElement(By.id("btnSave")).click();
				Thread.sleep(10000);
				 
		
	  
	  }
	  public  WebElement findElement(By by)throws Exception {
		    WebElement elem = driver.findElement(by);
		 
		    // draw a border around the found element
		    if (driver instanceof JavascriptExecutor) {
		        ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
		    } 
		    Thread.sleep(10);
		    
		    return elem;
		}

}
