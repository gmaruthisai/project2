package File_explorer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class File_download {
	
	static WebDriver driver;
  @Test
  public void Download() throws Exception
  {
	  driver = TestBrowser.OpenChromeBrowser();
	  
	  driver.get("https://opensource-demo.orangehrmlive.com/");
	  
	  findElement(By.id("txtUsername")).sendKeys("Admin");  
		findElement(By.id("txtPassword")).sendKeys("admin123");
		findElement(By.id("btnLogin")).click();
		
	 	 findElement(By.linkText("PIM")).click();
	 	 findElement(By.id("menu_pim_viewEmployeeList")).click();
	 	 findElement(By.id("empsearch_id")).sendKeys("0011");
	 	 findElement(By.id("searchBtn")).click();
	 	 Thread.sleep(10000);
	 	 findElement(By.cssSelector("#resultTable > tbody > tr > td:nth-child(2) > a")).click();
	 	 
	 	//*[@id="tblAttachments"]/tbody/tr/td[2]/a---> 
	 	 
	 	String str1="//*[@id='tblAttachments']/tbody/tr/td[2]";
	 	
	 	WebElement Element=findElement(By.xpath(str1));
		 String fname = Element.getText();
		 findElement(By.linkText(fname)).click();
		 
		 
		 
		 String SrcFile="C:\\Users\\lenovo\\Downloads"+fname;
	 	 String DestinationFile="C:\\HTML Report\\"+fname;

	 	Thread.sleep(6000);
	 	moveFile(SrcFile, DestinationFile);

		 
		 
  }
  public static void moveFile(String src, String dest ) throws InterruptedException {
      Path result = null;
      try {
         result =  Files.move(Paths.get(src), Paths.get(dest));
         
         
         Thread.sleep(5000);
      } catch (IOException e) {
         System.out.println("Exception while moving file: " + e.getMessage());
      }
      if(result != null) {
         System.out.println("File moved successfully.");
      }else{
         System.out.println("File movement failed.");
      }  
   }
  public WebElement findElement(By by)throws Exception {
	    WebElement elem = driver.findElement(by);
	 
	    // draw a border around the found element
	    if (driver instanceof JavascriptExecutor) {
	        ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	    } 
	    Thread.sleep(10);
	    
	    return elem;
	    
	    
	    
	}
	
  
  
  
}
