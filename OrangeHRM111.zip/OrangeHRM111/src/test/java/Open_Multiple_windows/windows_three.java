package Open_Multiple_windows;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class windows_three {
	
	WebDriver driver;
  @Test
  public void open_windows() throws Exception
  {
	  driver = TestBrowser.OpenChromeBrowser();
	  driver.get("https://opensource-demo.orangehrmlive.com/");
	  
	  ((JavascriptExecutor)driver).executeScript("window.open()");  //opens new tabs
		((JavascriptExecutor)driver).executeScript("window.open()");
		
		//strore all the open windows in ArrayList string
		//ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());

	  ArrayList<String> tabsopen = new  ArrayList<String>(driver.getWindowHandles());
	  
	  driver.switchTo().window(tabsopen.get(1));
	  driver.get("https://github.com/");

		driver.findElement(By.xpath("/html/body/div[1]/header/div/div[2]/div[2]/div[2]/a")).click();
		//driver.findElement(By.xpath("/html/body/div[1]/header/div/div/div/a")).click();
		driver.findElement(By.id("login_field")).sendKeys("gmaruthisai.369@gmail.com");
		driver.findElement(By.id("password")).sendKeys("MeeraBai@369");
		driver.findElement(By.name("commit")).click();
		
		
		driver.switchTo().window(tabsopen.get(0));
		//back to MainWindow
		driver.findElement(By.name("txtUsername")).sendKeys("Admin");
		driver.findElement(By.name("txtPassword")).sendKeys("admin123");
		
	  
	  driver.switchTo().window(tabsopen.get(2));
	  driver.get("https://facebook.com");
	  
//driver.close();
  }
}

