package CommonUtil;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.lang.reflect.Field;

/**
 * @author Sudhakar
 *
 */
public class OR2 {

// starts MercuryLoginPage by Sudhakar Date:12-Jan-2018
	public static String MLPage_UserNameTextbox = "//input[@type='text'and @name='userName']";
	public static String MLPage_PasswordTextbox = "//input[@type='password' and @name='password']";
	public static String MLPage_SignInButton = "//*[@name='login']";
	


}















