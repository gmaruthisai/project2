package Waits_synchronize;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class Explict_wait {
	
	WebDriver driver;
  @Test
  public void Logout() throws Exception
  {
	  
	  driver = TestBrowser.OpenChromeBrowser();
	  driver.get("https://opensource-demo.orangehrmlive.com/");
	  
	  findElement(By.xpath("//*[@id=\"txtUsername\"]")).sendKeys("Admin");
		findElement(By.cssSelector("#txtPassword")).sendKeys("admin123");
		findElement(By.cssSelector("#btnLogin")).click();
		findElement(By.id("menu_admin_viewAdminModule")).click();
		
		
	findElement(By.id("welcome")).click();
		
	WebDriverWait Explicitwait=  new WebDriverWait(driver,120);
	Explicitwait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Logout"))) ;
	 
		findElement(By.xpath("//*[@id=\"welcome-menu\"]/ul/li[3]/a")).click();
		
		//driver.quit();
		
  }
  
  public WebElement findElement(By by) throws Exception 
	{

		WebElement elem = driver.findElement(by);  
		
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		return elem;
	}

}
