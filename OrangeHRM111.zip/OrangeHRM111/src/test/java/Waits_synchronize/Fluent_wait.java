package Waits_synchronize;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class Fluent_wait {
	WebDriver driver;
  @Test
  public void Fluent_logout() throws Exception
  {
	  Fluent_wait Wait = new Fluent_wait();
			  Wait.OpenFirefox();
	  		  Wait.OpenHRM();
	  		  Wait.Welcome();
	  		  Wait.logout();
	  
	  
  }
  
  public void OpenFirefox() throws Exception
  {
  //driver = TestBrowser.OpenFirefoxBrowser();
  driver = TestBrowser.OpenChromeBrowser();
	  
  Thread.sleep(10000);
  }
  
  public void OpenHRM() throws Exception
  {
	  driver.get("https://opensource-demo.orangehrmlive.com/");
  }
  
  public void Welcome() throws Exception
  {
	  driver.findElement(By.id("txtUsername")).sendKeys("Admin");
	  driver.findElement(By.id("txtPassword")).sendKeys("admin123");
	  driver.findElement(By.id("btnLogin")).click();
	  driver.findElement(By.id("welcome")).click();

  }
  
  public void logout() throws Exception
  {
	  Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
		       .withTimeout(30, TimeUnit.SECONDS)
		       .pollingEvery(10, TimeUnit.SECONDS)			//for every 10 sec it will check the webelement 
		       .ignoring(NoSuchElementException.class);
		   
		   WebElement logout = wait.until(new Function<WebDriver,WebElement>() {
			     public WebElement apply(WebDriver driver) {
			       return driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/ul/li[2]/a"));
			     }
			   });
	  
		//driver.findElement(By.xpath("//*[@id=\"welcome-menu\"]/ul/li[3]/a")).click();
		   driver.findElement(By.linkText("Logout")).click();

  }
  
  
}


