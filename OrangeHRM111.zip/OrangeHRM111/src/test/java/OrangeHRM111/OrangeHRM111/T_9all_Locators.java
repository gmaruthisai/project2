
package OrangeHRM111.OrangeHRM111;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class T_9all_Locators {
	
	WebDriver driver;
	
  @Test
  public void test1() throws Exception {
	  
	  System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
		driver =new ChromeDriver();
		driver.manage().window().maximize() ;	
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		driver.findElement(By.cssSelector("#txtPassword")).sendKeys("admin123");
		driver.findElement(By.className("button")).click();
		
		
		
		driver.findElement(By.linkText("Admin")).click();
		driver.findElement(By.partialLinkText("Nationalit")).click();
		driver.findElement(By.id("btnAdd")).click();
		driver.findElement(By.id("nationality_name")).sendKeys("African594");
		driver.findElement(By.id("btnSave")).click();
		
  }
  
  
}
