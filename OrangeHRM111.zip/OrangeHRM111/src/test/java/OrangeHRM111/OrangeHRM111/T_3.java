package OrangeHRM111.OrangeHRM111;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class T_3 {
	
	WebDriver driver;
	
  @Test
  public void test3() throws Exception 
  {
	  
	  System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
		driver =new ChromeDriver();
		driver.manage().window().maximize() ;	
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		driver.findElement(By.id("txtPassword")).sendKeys("admin123");
		driver.findElement(By.id("btnLogin")).click();
		
		//driver.findElement(By.id("menu_admin_viewAdminModule")).click();
		driver.findElement(By.id("menu_leave_viewLeaveModule")).click();
		driver.findElement(By.id("menu_leave_viewLeaveList")).click();
		//driver.findElement(By.id("menu_admin_Job")).click();
		//driver.findElement(By.id("menu_admin_viewJobTitleList")).click();
	//	driver.findElement(By.id("btnAdd")).click();
		//driver.findElement(By.id("jobTitle_jobTitle")).sendKeys("job3");
		//driver.findElement(By.id("jobTitle_jobDescription")).sendKeys("job 3 desc");
		//driver.findElement(By.id("jobTitle_note")).sendKeys("job 3 note");
		//driver.findElement(By.id("btnSave")).click();
		Select drop = new Select(driver.findElement(By.id("leaveList_cmbSubunit")));
		
		drop.selectByVisibleText("Engineering");
		
		List<WebElement> List = drop.getOptions();
		
		for(WebElement Lists: List)
		{
			System.out.println(Lists.getText());
		}
		
		
		
  }
  
  
}
