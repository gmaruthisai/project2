package OrangeHRM111.OrangeHRM111;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import CommonUtil.TestBrowser;

public class Katalon_addskills {
	
	WebDriver driver;
	
	public void addskills_record() throws Exception

	
	{
		
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		 driver.get("https://opensource-demo.orangehrmlive.com/");
		    driver.findElement(By.xpath("//div[@id='divUsername']/span")).click();

		    driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		   
		     driver.findElement(By.id("txtPassword")).sendKeys("admin123");
		    driver.findElement(By.id("btnLogin")).click();
		    driver.findElement(By.xpath("//a[@id='menu_admin_viewAdminModule']/b")).click();
		    driver.findElement(By.id("menu_admin_viewSkills")).click();
		    driver.findElement(By.id("btnAdd")).click();
		    driver.findElement(By.id("skill_name")).click();
		 
		    driver.findElement(By.id("skill_name")).sendKeys("skill1");
		    
		    driver.findElement(By.id("skill_description")).sendKeys("skill1descrr");
		    driver.findElement(By.id("btnSave")).click();
		
	}

	public  WebElement findElement(By by) throws Exception 
	{

		WebElement elem = driver.findElement(by);  
		
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		return elem;
	}
	
}
