package OrangeHRM111.OrangeHRM111;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class T_5 {
	
	 WebDriver driver;
	
  @Test
  public void test5_non_static() throws Exception
  {
  		  T_5 testjobs = new T_5();		//here T_5 is class, testjobs is object-->classname object = new classname
  		testjobs.OpenChromeBrowser();	//here object.methodname();
  		testjobs.OpenOrangeHRM();
  		testjobs.Login();
  		testjobs.AddJobs();
  		testjobs.CloseBrowser();
  
  }
	 
		
		public void OpenChromeBrowser() throws Exception		//method for calling the browser
		
		{
			System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
			driver =new ChromeDriver();
			driver.manage().window().maximize() ;	
				
		}
		
		public void OpenOrangeHRM() throws Exception		//method for opening url
		
		{
			 driver.get("https://opensource-demo.orangehrmlive.com/");	
		}
		
		
		public void Login() throws Exception				//method for login
		
		{
			findElement(By.id("txtUsername")).sendKeys("Admin");
			findElement(By.id("txtPassword")).sendKeys("admin123");
			findElement(By.id("btnLogin")).click();
			
		}
		public void AddJobs() throws Exception				//method for adding jobs
		
		{
			findElement(By.id("menu_admin_viewAdminModule")).click();
			findElement(By.id("menu_admin_Job")).click();
			findElement(By.id("menu_admin_viewJobTitleList")).click();
			findElement(By.id("btnAdd")).click();
			findElement(By.id("jobTitle_jobTitle")).sendKeys("job4");
			findElement(By.id("jobTitle_jobDescription")).sendKeys("job 4 desc");
			findElement(By.id("jobTitle_note")).sendKeys("job 4 note");
			findElement(By.id("btnSave")).click();
		}
		public void CloseBrowser() throws Exception			//method for closing browser
		
		{
			driver.quit();
		}
		
  
  public WebElement findElement(By by) throws Exception 	//method for highlighting the webelement border
	{

		WebElement elem = driver.findElement(by);  
		
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		return elem;
	}
  
}
