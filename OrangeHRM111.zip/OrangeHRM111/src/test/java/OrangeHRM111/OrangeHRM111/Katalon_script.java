
package OrangeHRM111.OrangeHRM111;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class Katalon_script {
	
	WebDriver driver;
	
	
		
		 @Test
		  public void testUntitledTestCase() throws Exception {
			 
			 //System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
				//driver =new ChromeDriver();
				//driver.manage().window().maximize() ;	
			 driver = TestBrowser.OpenChromeBrowser();
		    driver.get("https://opensource-demo.orangehrmlive.com/");
		   
		    driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		    
		    driver.findElement(By.id("txtPassword")).sendKeys("admin123");
		    driver.findElement(By.id("btnLogin")).click();
		    driver.findElement(By.xpath("//a[@id='menu_admin_viewAdminModule']/b")).click();
		    driver.findElement(By.id("menu_admin_nationality")).click();
		    driver.findElement(By.id("btnAdd")).click();
		    driver.findElement(By.id("nationality_name")).click();
		   
		    driver.findElement(By.id("nationality_name")).sendKeys("american23");
		    driver.findElement(By.id("btnSave")).click();
		  }

	}
	
	
	


