package OrangeHRM111.OrangeHRM111;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class T_7 {
	
	static WebDriver driver;				//static method declaring static for all methods except for main test @Test
											//static parameters
	
	String TestURL="https://opensource-demo.orangehrmlive.com/";
	String username="Admin",password="admin123";
	String jobTitle_jobTitle="Job7",jobTitle_jobDescription="Job7 descr",jobTitle_note="Job7  Note";
	
	
  @Test
  public void test7() throws Exception
  {
	  T_7.OpenChromeBrowser();				//classname.methodname()
	  T_7.OpenOrangeHRM(TestURL);
	  T_7.Login(username,password);
	  T_7.AddJobs(jobTitle_jobTitle,jobTitle_jobDescription,jobTitle_note);
	  //T_6.CloseBrowser();
	  
  }
	 
		
		public static void OpenChromeBrowser() throws Exception		
		
		{
			System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
			driver =new ChromeDriver();
			driver.manage().window().maximize() ;	
				
		}
		
		public static void OpenOrangeHRM(String TestURL1) throws Exception		
		
		{
			 driver.get(TestURL1);	
		}
		
		
		public static  void Login(String username1,String password1) throws Exception		
		
		{
			findElement(By.id("txtUsername")).sendKeys(username1);
			findElement(By.id("txtPassword")).sendKeys(password1);
			findElement(By.id("btnLogin")).click();
			
		}
		public static  void AddJobs(String jobTitle_jobTitle,String jobTitle_jobDescription,String jobTitle_note) throws Exception		
		
		{
			findElement(By.id("menu_admin_viewAdminModule")).click();
			findElement(By.id("menu_admin_Job")).click();
			findElement(By.id("menu_admin_viewJobTitleList")).click();
			findElement(By.id("btnAdd")).click();
			findElement(By.id("jobTitle_jobTitle")).sendKeys(jobTitle_jobTitle);
			findElement(By.id("jobTitle_jobDescription")).sendKeys(jobTitle_jobDescription);
			findElement(By.id("jobTitle_note")).sendKeys(jobTitle_note);
			findElement(By.id("btnSave")).click();
		}
		public static void CloseBrowser() throws Exception		
		
		{
			driver.quit();
		}
		
  
  public static WebElement findElement(By by) throws Exception 
	{

		WebElement elem = driver.findElement(by);  
		
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		return elem;
	}
  
}
