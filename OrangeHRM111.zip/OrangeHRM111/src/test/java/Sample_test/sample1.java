package Sample_test;

import org.testng.annotations.Test;

public class sample1
{
		int a,b,c;

  @Test
  public void Addition()
  
  {
	  a=16;
	  b=14;
	  c=a+b;
	   
	  System.out.println("Sum of a and b :"+c);
	  System.out.println("Value if a :"+a);
	  System.out.println("Value of b :"+b);
	  
  }
}


