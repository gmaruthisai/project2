package Driver;

public interface drift  {
	
public abstract void Hello();
}
