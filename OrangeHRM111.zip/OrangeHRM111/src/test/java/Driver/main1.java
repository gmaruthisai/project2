package Driver;

public class main1 implements drift {

	public static void main(String[] args) {
		drift D1= new main1();
		D1.Hello();

	}

	@Override
	public void Hello() {
		System.out.println("heesgfjhgjkh");
		
	}

}
