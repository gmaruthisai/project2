package Driver;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class maindriver extends Test1 {

	WebDriver driver;
	public static void main(String[] args) {
		System.out.println("the driverkey");

	}

	
	@Test
	public void Login() throws Exception {
		
		driver = TestBrowser.OpenChromeBrowser();
		
	}

}
