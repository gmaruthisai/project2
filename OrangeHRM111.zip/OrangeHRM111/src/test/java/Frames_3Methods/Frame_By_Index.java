package Frames_3Methods;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class Frame_By_Index {
	WebDriver driver;
  @Test
  public void Test_Index() throws Exception
  {
	  
	  driver = TestBrowser.OpenChromeBrowser();
	  driver.get("http://www.bhavasri.com/Frames/AllContacts.html");
	  
	  List<WebElement> frames_Index = driver.findElements(By.tagName("iframe"));
		System.out.println("Number of frames: " + frames_Index.size());

	  
	  
	  driver.switchTo().frame(frames_Index.get(0));
	  findElement(By.id("fname")).sendKeys("Selenium");
	  findElement(By.id("lname")).sendKeys("Maruthi");
	  findElement(By.id("subject1")).sendKeys("sai");
	  
	  driver.switchTo().defaultContent();
	  
	  
	  
	  driver.switchTo().frame(frames_Index.get(1));
	  findElement(By.id("fname")).sendKeys("Selenium");
	  findElement(By.id("lname")).sendKeys("Maruthi");
	  findElement(By.id("subject")).sendKeys("sai");
  }
  
  public  WebElement findElement(By by) throws Exception 
	{
				
		WebElement elem = driver.findElement(by);  
		
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		return elem;
	}
}
