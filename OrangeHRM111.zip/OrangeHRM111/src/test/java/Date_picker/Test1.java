package Date_picker;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class Test1 {
	
	WebDriver driver;
  @Test
  public void Leave() throws Exception
  {
	  
		driver = TestBrowser.OpenChromeBrowser();
		driver.get("https://opensource-demo.orangehrmlive.com/");

		findElement(By.id("txtUsername")).sendKeys("Admin");
		findElement(By.id("txtPassword")).sendKeys("admin123");
		findElement(By.id("btnLogin")).click();

		findElement(By.linkText("Leave")).click();
		findElement(By.linkText("Leave List")).click();

		findElement(By.xpath("//*[@id=\'frmFilterLeave\']/fieldset/ol/li[1]/img")).click();

		Select month = new Select(findElement(By.className("ui-datepicker-month")));
		month.selectByVisibleText("Oct");

		Select year = new Select(findElement(By.className("ui-datepicker-year")));
		year.selectByVisibleText("1995");

		String str3 = "//*[text()='" + 9 + "']";			//*[@id="ui-datepicker-div"]/table/tbody/tr[4]/td[4]/a

		Actions date = new Actions(driver);
		WebElement date1 = findElement(By.xpath(str3));
		date.moveToElement(date1).click().build().perform();
	 	
		
		
		
		
  }
	public  WebElement findElement(By by) throws Exception 
	{

		WebElement elem = driver.findElement(by);  
		
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		return elem;
	}

}
