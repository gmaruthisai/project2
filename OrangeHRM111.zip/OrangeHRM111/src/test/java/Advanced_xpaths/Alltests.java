package Advanced_xpaths;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Alltests {
	WebDriver driver;
  @Test
  public void Alltypestest() throws Exception
  {
	  

		System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
		driver =new ChromeDriver();
		driver.manage().window().maximize() ;	
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
		findElement(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div[2]/form/div[2]/input")).sendKeys("Admin");
		findElement(By.xpath("//*[@id=\'txtPassword\']")).sendKeys("admin123");
		findElement(By.id("btnLogin")).click();
		
		findElement(By.xpath("//b[text()='Admin']")).click();
		findElement(By.xpath("//*[contains(text(),'National')]")).click();
		
		//findElement(By.xpath("//input[(text(),'Add')]")).click();  //*[@id="btnAdd"]
		//*[@id="btnAdd"]
		findElement(By.xpath("//input[text()='btnAdd']")).click();
	  
  }
  
  public  WebElement findElement(By by) throws Exception 
	{
				
		WebElement elem = driver.findElement(by);  
		
		if (driver instanceof JavascriptExecutor) 
		{
		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
	 
		}
		return elem;
	}
}
