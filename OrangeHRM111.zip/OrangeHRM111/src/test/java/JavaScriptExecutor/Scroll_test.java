package JavaScriptExecutor;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import CommonUtil.TestBrowser;

public class Scroll_test {
	
	static WebDriver driver;
  @Test
  public void Scrollview() throws Exception
  {
	  driver = TestBrowser.OpenChromeBrowser();
	 
	   driver.get("https://www.amazon.in/");
	   
	   driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	   
	   ((JavascriptExecutor)driver).executeScript("window.open()");		//launches new tab for github
	   ((JavascriptExecutor)driver).executeScript("window.open()");
	   
	   
	   ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
	   
	   driver.switchTo().window(tabs.get(1));
	   driver.get("https://github.com/");

		driver.findElement(By.xpath("/html/body/div[1]/header/div/div[2]/div[2]/div[2]/a")).click();
		driver.findElement(By.id("login_field")).sendKeys("gmaruthisai.369@gmail.com");
		driver.findElement(By.id("password")).sendKeys("MeeraBai@369");
		driver.findElement(By.name("commit")).click();
		
		driver.switchTo().window(tabs.get(2));
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
		WebElement username = findElement(By.id("txtUsername"));
		WebElement password = findElement(By.id("txtPassword"));
		
		
		WebElement button = findElement(By.id("btnLogin"));
		
		
		JavascriptExecutor js1 = (JavascriptExecutor)driver;
		
		js1.executeScript("arguments[0].setAttribute('value','Admin')", username);
		js1.executeScript("arguments[0].setAttribute('value','admin123')", password);
		//js1.executeScript("arguments[0].Click();",Login);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 js1.executeScript("arguments[0].click();", button);
	        
		
		driver.switchTo().window(tabs.get(0));							//back to main amazon site
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		   
	   
	   WebElement object = findElement(By.xpath("//*[@id=\"navFooter\"]/div[1]/div/div[3]/ul/li[3]/a"));
	   
	   JavascriptExecutor js = (JavascriptExecutor)driver;
	   
	   //js.executeScript("arguments[0].scrollIntoview();", object);
	  js.executeScript("arguments[0].scrollIntoView();",object);
	   
	  
  }
  
  
  
  
  
  public  WebElement findElement(By by) throws Exception 
 	{
 				
 		 WebElement elem = driver.findElement(by);    	    
 		
 		 
 		if (driver instanceof JavascriptExecutor) 
 		{
 		 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
 	 
 		}
 		
 		return elem;
 	}
}
