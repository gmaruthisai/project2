package BasicsOf_Java;

public class Test2 {
	
	static int i=400;
	static int j=245;
	static int k;

	public static void main(String[] args) {
		if(i>400)
		{
		k = i-j;
		
		System.out.println("value of K:" +k);
		}
		else if(i<400)
		{
			k = i+j;
			System.out.println("value of K:" +k);
		}
		
		else if (i==400)
		{
			System.out.println("value of i equals to our condition" );
		}
	}

}
