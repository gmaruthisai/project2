package BasicsOf_Java;

public class Test5 {
	
	String Name;
	int ID;
	String status;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
	
	public class Encapsule{
	
	public  void main(String[] args)
	{
		Test5 T1 = new Test5();
		T1.setName("Maruthi sai");
		T1.setID(352);
		T1.setStatus("Approved");
		
		System.out.println(T1.getName());
		System.out.println(T1.getID());
		System.out.println(T1.getStatus());
	}

}
