package BasicsOf_Java;


class Test
{
	String Name;
	int ID;
	String status;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}



}

public class Encapsulation {

	public static void main(String[] args) {
		Test T1 = new Test();
		T1.setName("Maruthi sai");
		T1.setID(352);
		T1.setStatus("Approved");
		
		System.out.println("Name of the candidate:" +T1.getName());
		System.out.println("Id of candidate:" +T1.getID());
		System.out.println("Status of candidate:" +T1.getStatus());

	}

}
