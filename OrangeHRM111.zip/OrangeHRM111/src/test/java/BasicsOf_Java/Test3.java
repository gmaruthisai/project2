package BasicsOf_Java;

public class Test3 {
	
	static String  i;
	static String  j;
	static double  k;

	public  void main(String i, String j, double k)
	{
		i = "Hyderabad";
		j = "secunderabad";
		System.out.println("Twin cities:" +i );
		System.out.println("favorite:" +j);
		
		k= 5.2;
		System.out.println("portion of each:" +k);

	}

}
