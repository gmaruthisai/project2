package BasicsOf_Java;

import org.testng.annotations.Test;

public class Test1 {
  @Test
  public void numerical() throws Exception
  {
	  
	  
	  
	  	int n = 4;
	  	
	  	if (n==0)
	  	{
	  		System.out.println("nothing");
	  		System.out.println("byee");
	  	} 
	  	else if (n%2==0)
	  	{
	  		System.out.println("Even");
	  	}
	  	
	  	else if(n%2!=0)		// !--> denotes not equal to zero
	  	{
	  		System.out.println("Odd");
	  	}
	  }

  }

