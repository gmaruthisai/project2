package BasicsOf_Java;

public class Encapsulation1 {
	
	String Name;
	int  rollno;
	double percentage;

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public static void main(String[] args) {
		Encapsulation1 E1= new Encapsulation1();
		E1.setName("Gaddam Maruthi sai");
		E1.setRollno(444);
		E1.setPercentage(74.64);
		
		System.out.println("Name of person"+E1.getName());
		System.out.println("ID of person"+E1.getRollno());
		System.out.println("Percentage of person"+E1.getPercentage());

	}

}
