package Excel_projects;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class project_xlsx {
	
	public XSSFWorkbook workbook = null;		//first step for importing the excel supporting files
	public XSSFSheet sheet = null;
	public XSSFRow  row = null;
	public XSSFCell cell = null;
	
	public FileInputStream fis = null;
	public FileOutputStream fout = null;
	
	String  TestURL, UserName, Password, AddNationality;
	WebDriver driver;
  @Test
  
  public void exceldata() throws Exception
  {
	  project_xlsx object = new project_xlsx();
	  
	  TestURL = object.getCellData("C://HTML Report//OrangeHRM6//TC01_Nationality1.xlsx","Sheet3",1,0);
	  UserName=object.getCellData("C://HTML Report//OrangeHRM6//TC01_Nationality1.xlsx","Sheet3",1,1);
	  Password=object.getCellData("C://HTML Report//OrangeHRM6//TC01_Nationality1.xlsx","Sheet3",1,2);
	// AddNationality=object.getCelldata("C://HTML Report//OrangeHRM6//TC01_Nationality1.xlsx","Sheet3",1,3);
		AddNationality = object.getCellData("C://HTML Report//OrangeHRM6//TC01_Nationality1.xlsx", "sheet3", 1, 3);
	  System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe" );
	  driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  
	  driver.get(TestURL);
	  	 findElement(By.name("txtUsername")).sendKeys(UserName);
		 findElement(By.name("txtPassword")).sendKeys(Password);
		 findElement(By.id("btnLogin")).click();
		 findElement(By.id("menu_admin_viewAdminModule")).click();
		 findElement(By.id("menu_admin_nationality")).click(); 
		 findElement(By.id("btnAdd")).click();
		 findElement(By.id("nationality_name")).sendKeys(AddNationality);
		 driver.quit();
  }
  
  public String getCellData(String xlFilePath, String sheetName,int rowNum,int column) throws Exception
  {
  	fis = new FileInputStream(xlFilePath);
      workbook = new XSSFWorkbook(fis);
      sheet = workbook.getSheet(sheetName);
      row = sheet.getRow(rowNum);
      cell = row.getCell(column);
     
      if(cell.getCellTypeEnum() == CellType.STRING)
      {	
      	String str6=cell.getStringCellValue();
      	workbook.close();
      	fis.close();
          return str6;
      }
      
      else if(cell.getCellTypeEnum() == CellType.NUMERIC)
      {	
      	
      	int i = (int)cell.getNumericCellValue(); 
      	String str6 = String.valueOf(i); 
      	workbook.close();
      	fis.close();
          return str6;
      }
      else 
      {
      	String str6=cell.getStringCellValue();
      	workbook.close();
      	fis.close();
          return str6;
      }
      
  }
      public  WebElement findElement(By by) throws Exception 
		{
					
			 WebElement elem = driver.findElement(by);    	    
			
			 
			if (driver instanceof JavascriptExecutor) 
			{
			 ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", elem);
		 
			}
			
			return elem;
		}

  
  
  
  
  
  
  
  











}
